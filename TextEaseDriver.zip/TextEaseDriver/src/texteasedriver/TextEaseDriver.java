/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package texteasedriver;

import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author hayapirzada
 */
public class TextEaseDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    new RegistrationWindow();
    new TextToSpeech();
    }
    
}
